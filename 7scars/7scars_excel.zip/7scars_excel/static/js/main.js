// ========== Utilities ==========
function normalizeArabicJS(t){
  t = (t || '').toString().trim();
  t = t.replace(/[إأآا]/g, 'ا');
  t = t.replace(/\s+/g, '');
  t = t.replace(/ة/g, 'ه');
  t = t.replace(/[^\w\u0600-\u06FF]/g, '');
  return t;
}

function fmtDate(d){
  if(!d) return '';
  const x = new Date(d);
  if(isNaN(x.getTime())) return d;
  return x.toLocaleDateString('ar-EG');
}

function buildTable(rows){
  const headers = [
    ['plate','اللوحة'],
    ['color','اللون'],
    ['oil_date','تاريخ تغيير الزيت'],
    ['odometer','عداد'],
    ['oil_mileage','ممشى الزيت'],
    ['make','الشركة'],
    ['model','الموديل'],
    ['created_at','أُضيف في']
  ];
  let html = '<table class="table"><thead><tr>';
  headers.forEach(([k,h])=> html += `<th>${h}</th>`);
  html += '</tr></thead><tbody>';
  rows.forEach(r=>{
    html += '<tr>';
    headers.forEach(([k])=>{
      let v = r[k] ?? '';
      if(k==='oil_date' || k==='created_at') v = fmtDate(v);
      html += `<td>${v}</td>`;
    });
    html += '</tr>';
  });
  html += '</tbody></table>';
  return html;
}

async function fetchRows({q='',limit='all'}){
  const p = new URLSearchParams();
  if(q) p.set('q', q);
  if(limit && limit!=='all') p.set('limit', limit);
  const res = await fetch('/api/records?'+p.toString());
  const data = await res.json();
  return data?.rows || [];
}

async function postRecord(payload){
  const res = await fetch('/api/records',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  });
  return await res.json();
}

// ========== Page Init ==========
function initPage(opts){
  const {scope, tableWrapId, searchId, filterId, refreshId, formId, statusId} = opts;
  const wrap = document.getElementById(tableWrapId);
  const searchEl = document.getElementById(searchId);
  const filterEl = document.getElementById(filterId);
  const refreshBtn = document.getElementById(refreshId);

  async function refresh(){
    const q = searchEl?.value || '';
    const limit = filterEl?.value || 'all';
    const rows = await fetchRows({q, limit});
    wrap.innerHTML = buildTable(rows);
  }

  if(refreshBtn) refreshBtn.addEventListener('click', refresh);
  if(searchEl){
    searchEl.addEventListener('input', ()=>{ refresh(); });
  }
  if(filterEl){ filterEl.addEventListener('change', refresh); }

  if(scope==='maintenance' && formId){
    const form = document.getElementById(formId);
    const stat = document.getElementById(statusId);
    form.addEventListener('submit', async (e)=>{
      e.preventDefault();
      const payload = Object.fromEntries(new FormData(form).entries());
      payload.plate = payload.plate?.trim();
      payload.color = payload.color?.trim();
      payload.make  = payload.make?.trim();
      payload.model = payload.model?.trim();
      try{
        const r = await postRecord(payload);
        stat.textContent = r.success ? '✔️ تم الحفظ' : ('❌ '+ (r.message||'خطأ'));
        await refresh();
        form.reset();
        setTimeout(()=> stat.textContent='', 2500);
      }catch(err){
        stat.textContent = '❌ فشل الاتصال بالخادم';
      }
    });
  }
  refresh();
}
