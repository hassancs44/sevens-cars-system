from flask import Flask, render_template, request, jsonify
from datetime import datetime
import pandas as pd
import os, re

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
EXCEL_PATH = os.path.join(DATA_DIR, "cars_data.xlsx")
SHEET_NAME = "records"

app = Flask(__name__)

COLUMNS = [
    "plate","color","oil_date","odometer","oil_mileage","make","model",
    "n_plate","n_all","created_at","updated_at"
]

# --------------- Utilities ---------------
def normalize_arabic(text: str) -> str:
    if text is None:
        return ""
    t = str(text).strip()
    t = re.sub(r"[إأآا]", "ا", t)
    t = re.sub(r"\s+", "", t)
    t = t.replace("ة", "ه")
    t = re.sub(r"[^\w\u0600-\u06FF]", "", t)
    return t

def ensure_excel():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(EXCEL_PATH):
        df = pd.DataFrame(columns=COLUMNS)
        df.to_excel(EXCEL_PATH, sheet_name=SHEET_NAME, index=False)

def read_df():
    ensure_excel()
    try:
        df = pd.read_excel(EXCEL_PATH, sheet_name=SHEET_NAME, dtype=str)
    except Exception:
        df = pd.DataFrame(columns=COLUMNS)
    # Ensure integer columns are preserved as string; we'll cast later
    for col in COLUMNS:
        if col not in df.columns:
            df[col] = ""
    return df

def write_df(df: pd.DataFrame):
    ensure_excel()
    # Reorder columns and write
    df = df.reindex(columns=COLUMNS)
    with pd.ExcelWriter(EXCEL_PATH, engine="openpyxl", mode="w") as writer:
        df.to_excel(writer, sheet_name=SHEET_NAME, index=False)

# --------------- Pages ---------------
@app.before_request
def setup():
    ensure_excel()

@app.route('/')
def index():
    return render_template('rental.html', title='مكتب التأجير')

@app.route('/maintenance')
def maintenance_page():
    return render_template('maintenance.html', title='الورشة (الصيانة)')

@app.route('/rental')
def rental_page():
    return render_template('rental.html', title='مكتب التأجير')

# --------------- APIs ---------------
@app.route('/api/records', methods=['GET'])
def api_records_list():
    q = (request.args.get('q', '') or '').strip()
    limit = (request.args.get('limit', 'all') or 'all').strip()

    df = read_df()

    # Filter by query
    if q:
        nq = normalize_arabic(q)
        # ensure n_* exist
        if "n_plate" not in df.columns: df["n_plate"] = ""
        if "n_all" not in df.columns: df["n_all"] = ""
        mask = df["n_plate"].astype(str).str.contains(nq, na=False) | df["n_all"].astype(str).str.contains(nq, na=False)
        df = df[mask]

    # Sort by created_at desc (fallback to oil_date if missing)
    if "created_at" in df.columns:
        df = df.sort_values(by="created_at", ascending=False, na_position="last")
    elif "oil_date" in df.columns:
        df = df.sort_values(by="oil_date", ascending=False, na_position="last")

    # Apply limit
    if limit.isdigit():
        df = df.head(int(limit))

    # Cast numeric columns back to numeric for API (optional)
    def safe_int(x):
        try: return int(float(x))
        except: return x

    out = df.fillna("")
    if "odometer" in out.columns:
        out["odometer"] = out["odometer"].apply(safe_int)
    if "oil_mileage" in out.columns:
        out["oil_mileage"] = out["oil_mileage"].apply(safe_int)

    return jsonify({"success": True, "rows": out[COLUMNS[:8]+['created_at']].to_dict(orient="records")})

@app.route('/api/records', methods=['POST'])
def api_records_add():
    data = request.get_json(force=True) or {}
    required = ['plate','color','oil_date','odometer','oil_mileage','make','model']
    missing = [f for f in required if not str(data.get(f, '')).strip()]
    if missing:
        return jsonify({"success": False, "message": f"حقول ناقصة: {', '.join(missing)}"}), 400

    plate = str(data['plate']).strip()
    color = str(data['color']).strip()
    oil_date = str(data['oil_date']).strip()
    make = str(data['make']).strip()
    model = str(data['model']).strip()
    try:
        odometer = int(float(data['odometer']))
        oil_mileage = int(float(data['oil_mileage']))
    except Exception:
        return jsonify({"success": False, "message": "عداد/ممشى الزيت يجب أن يكون رقمًا"}), 400

    # Validate date
    try:
        datetime.fromisoformat(oil_date)
    except Exception:
        return jsonify({"success": False, "message": "صيغة التاريخ غير صحيحة (YYYY-MM-DD)"}), 400

    n_plate = normalize_arabic(plate)
    n_all = normalize_arabic(f"{plate} {color} {make} {model}")
    now_iso = datetime.now().isoformat(timespec='seconds')

    df = read_df()
    new_row = {
        "plate": plate,
        "color": color,
        "oil_date": oil_date,
        "odometer": odometer,
        "oil_mileage": oil_mileage,
        "make": make,
        "model": model,
        "n_plate": n_plate,
        "n_all": n_all,
        "created_at": now_iso,
        "updated_at": now_iso,
    }
    df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
    write_df(df)

    return jsonify({"success": True})

if __name__ == "__main__":
    app.run(debug=True)
